#ifndef COSC1076_TEST_CLASS
#define COSC1076_TEST_CLASS

class TestClass {
public:
   TestClass();
   TestClass(int value);
   ~TestClass();

   void method();

   int value;
};

#endif // COSC1076_TEST_CLASS
