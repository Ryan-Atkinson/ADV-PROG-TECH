
#include "Node.h"

#include <iostream>

using std::string;
using std::cout;
using std::endl;

Node::Node(int data, Node* next) :
   data(data),
   next(next)
{
   cout << "Node Create: " << data << endl;
}

Node::Node(const Node& other) :
   data(other.data),
   next(other.next)
{
   cout << "Node Copy: " << data << endl;
}

Node::~Node() {
   cout << "Node Deconstructor: " << data << endl;
   next = nullptr;
}
