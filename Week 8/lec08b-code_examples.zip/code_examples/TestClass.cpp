
#include "TestClass.h"

#include <iostream>
#include <string>

using std::string;
using std::cout;
using std::endl;

TestClass::TestClass() {
   cout << "TestClass Constructor" << endl;
   value = 0;
}

TestClass::TestClass(int value) {
   cout << "TestClass Constructor with value: " << value << endl;
   this->value = value;
}

TestClass::~TestClass() {
   cout << "TestClass Delete (value: " << value << ")" << endl;
}

void TestClass::method() {
   cout << "TestClass method" << endl;
}
