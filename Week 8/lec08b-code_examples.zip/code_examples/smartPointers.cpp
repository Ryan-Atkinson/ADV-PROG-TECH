

#include <iostream>
#include <string>
#include <memory>

#include "TestClass.h"

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;

std::unique_ptr<int> returnUnique();
void getUnique(std::unique_ptr<int>& ptr);
void testSharedPointer();

int main(void) {



   return EXIT_SUCCESS;
}

std::unique_ptr<int> returnUnique() {
   return nullptr;
}

void getUnique(std::unique_ptr<int>& ptr) {
}

void testSharedPointer() {
}
