
#include "LinkedList.h"

#include <exception>
#include <string>
#include <iostream>

using std::string;
using std::cout;
using std::endl;

LinkedList::LinkedList() {
   throw std::runtime_error("unimplemented");
}

LinkedList::~LinkedList() {
   throw std::runtime_error("unimplemented");
}

int LinkedList::size() {
   throw std::runtime_error("unimplemented");
   return 0;
}

void LinkedList::clear() {
   throw std::runtime_error("unimplemented");
}

int LinkedList::get(int i) {
   throw std::runtime_error("unimplemented");
   return 0;
}

void LinkedList::addFront(int data) {
   throw std::runtime_error("unimplemented");
}

void LinkedList::addBack(int data) {
   throw std::runtime_error("unimplemented");
}

bool LinkedList::contains(int value){
   throw std::runtime_error("unimplemented");
   return false;
}

void LinkedList::deleteFront() {
   throw std::runtime_error("unimplemented");
}

void LinkedList::deleteBack(){
   throw std::runtime_error("unimplemented");
}
