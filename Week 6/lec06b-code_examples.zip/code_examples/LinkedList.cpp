
#include "LinkedList.h"

LinkedList::LinkedList() {
   head = nullptr;
}

LinkedList::~LinkedList() {

}

int LinkedList::size() {
   return 0;
}

void LinkedList::clear() {

}

int LinkedList::get(int i) {
   return 0;
}

void LinkedList::addFront(int data) {

}

void LinkedList::addBack(int data) {

}
