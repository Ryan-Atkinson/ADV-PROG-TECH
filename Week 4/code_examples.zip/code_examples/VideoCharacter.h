
#include <string>

class VideoCharacter {
public:
   VideoCharacter(std::string& name);
   ~VideoCharacter();

   std::string getName();
   int         getHp();

private:
   std::string name;
   int         hp;
};
