
#include "VideoCharacter.h"

#include <iostream>

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;

int main(void) {
   std::string name = "Scanlan";
   VideoCharacter* pc = nullptr;
   pc = NULL;
   pc = new VideoCharacter(name);

   cout << pc->getName() << endl;

   return EXIT_SUCCESS;
}
