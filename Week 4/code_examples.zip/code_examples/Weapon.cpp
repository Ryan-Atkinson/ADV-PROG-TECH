
#include "Weapon.h"

Weapon::Weapon(int type)
{
   this->type = type;
}

Weapon::~Weapon() {
}

int Weapon::getType() {
   return type;
}
