
#define WEAPON_SWORD    0
#define WEAPON_SPEAR    1
#define WEAPON_PIKE     2
#define WEAPON_TRIDENT  3

class Weapon {
public:
   Weapon(int type);
   ~Weapon();

   int getType();

private:
   int type;
};
