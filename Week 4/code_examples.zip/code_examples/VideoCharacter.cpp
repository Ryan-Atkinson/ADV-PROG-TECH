
#include "Weapon.h"
#include "VideoCharacter.h"

#define MAX_HP    100

VideoCharacter::VideoCharacter(std::string& name)
{
   this->name = name;
   this->hp = MAX_HP;
}

VideoCharacter::~VideoCharacter() {
}

std::string VideoCharacter::getName() {
   return name;
}

int VideoCharacter::getHp() {
   return hp;
}
