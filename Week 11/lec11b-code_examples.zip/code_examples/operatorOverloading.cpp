
#include <iostream>
#include <string>

#include "Vector.h"

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;

void compare(Vector& vec1, Vector& vec2);

int main(void) {
   Vector vec1;
   Vector vec2;

   vec1.print();
   compare(vec1, vec2);

   // cout << "Get 1: " << vec1.get(1) << endl;
   cout << "Get 1: " << vec1[1] << endl;
   cout << "Set" << endl;
   // vec1.set(1, 7);
   vec1[1] = 7;
   vec1.print();
   compare(vec1, vec2);

   cout << "Add" << endl;
   // vec2.add(vec1);
   vec2 += vec1;
   compare(vec1, vec2);
   
   vec2 += 1;
   vec2.print();
   vec2 = vec1 + vec2;
   vec2.print();

   // Vector vec3;
   Vector vec3 = vec2;
   vec3 = vec2;
   vec3[9] = -99;
   vec2.print();
   vec3.print();
   compare(vec3, vec2);

   // Inc/Dec
   cout << "Operator ++" << endl;
   ++vec3;
   vec3.print();
   Vector vec4;
   Vector vec5;
   vec4 = ++vec3;
   vec5 = vec3++;
   // vec3.print();
   // vec4.print();
   // vec5.print();
   cout << vec3 << endl;
   cout << vec4 << endl;
   cout << vec5 << endl;

   return EXIT_SUCCESS;
}

void compare(Vector& vec1, Vector& vec2) {
   if (vec1 == vec2) {
      cout << "vec == vec" << endl;
   } else {
      cout << "vec != vec" << endl;
   }
}
