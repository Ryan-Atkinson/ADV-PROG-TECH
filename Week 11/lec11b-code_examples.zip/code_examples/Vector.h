
#ifndef WEEK11__MATRIX
#define WEEK11__MATRIX

#include <iostream>

class Vector {
public:
   Vector();
   Vector(Vector& other);
   ~Vector();

   double get(int col) const;
   void set(int col, double value);
   void add(const Vector& other);

   void print() const;

   bool operator==(const Vector& other) const;
   double& operator[](const int index);

   Vector& operator+=(const Vector& other);
   Vector& operator+=(int value);
   Vector operator+(const Vector& other) const;

   Vector& operator=(const Vector& other);

   // Increment operator
   Vector& operator++();
   Vector operator++(int);

   // Must be a non-member function - ie NOT method
   // std::ostream& operator<<(std::ostream& os);

private:
   double vec[10];
};

std::ostream& operator<<(std::ostream& os, Vector& vec);

#endif // WEEK11__MATRIX
