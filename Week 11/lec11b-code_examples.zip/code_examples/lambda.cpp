
#include <iostream>
#include <string>

#include "Vector.h"

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;


int main(void) {
   // Lambda compare
   auto compare = [](Vector& v1, Vector& v2) {
      if (v1 == v2) {
         cout << "vec == vec" << endl;
      } else {
         cout << "vec != vec" << endl;
      }
   };

   Vector vec1;
   Vector vec2;

   vec1.print();
   compare(vec1, vec2);

   // cout << "Get 1: " << vec1.get(1) << endl;
   cout << "Get 1: " << vec1[1] << endl;
   cout << "Set" << endl;
   // vec1.set(1, 7);
   vec1[1] = 7;
   vec1.print();
   compare(vec1, vec2);

   cout << "Add" << endl;
   // vec2.add(vec1);
   vec2 += vec1;
   compare(vec1, vec2);


   return EXIT_SUCCESS;
}

// void compare(Vector& vec1, Vector& vec2) {
//    if (vec1 == vec2) {
//       cout << "vec == vec" << endl;
//    } else {
//       cout << "vec != vec" << endl;
//    }
// }
