
#include "Vector.h"

#include <iostream>

#define COLS   10

using std::cout;
using std::endl;

Vector::Vector() {
   for (int c = 0; c != COLS; ++c) {
      vec[c] = 0;
   }
}

Vector::Vector(Vector& other) {
   cout << "** vector copy constructor" << endl;
   for (int c = 0; c != COLS; ++c) {
      vec[c] = other.vec[c];
   }
}

Vector::~Vector() {
}

double Vector::get(int col) const {
   return vec[col];
}

void Vector::set(int col, double value) {
   vec[col] = value;
}

void Vector::add(const Vector& other) {
   for (int c = 0; c != COLS; ++c) {
      vec[c] += other.vec[c];
   }
}

void Vector::print() const {
   for (int c = 0; c != COLS; ++c) {
      cout << vec[c] << " ";
   }
   cout << endl;
}

std::ostream& operator<<(std::ostream& os, Vector& vec) {
   os << "vector: ";
   for (int c = 0; c != COLS; ++c) {
      os << vec[c] << " ";
   }
   return os;
}

bool Vector::operator==(const Vector& other) const {
   bool match = true;
   for (int c = 0; c != COLS; ++c) {
      match = match && (vec[c] == other.vec[c]);
   }
   return match;
}

double& Vector::operator[](const int index) {
   return vec[index];
}

Vector& Vector::operator+=(const Vector& other) {
   cout << "** vector += operator (vec)" << endl;
   for (int c = 0; c != COLS; ++c) {
      vec[c] += other.vec[c];
   }
   return *this;
}

Vector& Vector::operator+=(int value) {
   cout << "** vector += operator (int)" << endl;
   for (int c = 0; c != COLS; ++c) {
      vec[c] += value;
   }
   return *this;
}

Vector Vector::operator+(const Vector& other) const {
   cout << "** vector + operator" << endl;
   Vector newVec;
   for (int c = 0; c != COLS; ++c) {
      newVec.vec[c] = vec[c] + other.vec[c];
   }
   return newVec;
}

Vector& Vector::operator=(const Vector& other) {
   cout << "** vector = operator" << endl;
   for (int c = 0; c != COLS; ++c) {
      vec[c] = other.vec[c];
   }
   return *this;
}

Vector& Vector::operator++() {
   cout << "** vector++" << endl;
   for (int c = 0; c != COLS; ++c) {
      vec[c] += 1;
   }
   return *this;
}

Vector Vector::operator++(int) {
   cout << "** ++vector" << endl;
   Vector copy(*this);
   operator++();
   return copy;
}
