
#include <iostream>
#include <fstream>

#define EXIT_SUCCESS    0

using std::cout;
using std::endl;

void readMaze(std::string& filename);

int main(int argc, char** argv) {
   cout << "Num args: " << argc << endl;
   cout << "First arg: " << argv[0] << endl;

   // Storing args into array of string
   // std::string stringArgs[argc];

   // Load maze from file
   if (argc >= 2) {
      readMaze(stringArgs[1]);
   }

   return EXIT_SUCCESS;
}


void readMaze(std::string& filename) {
   // TODO
}
