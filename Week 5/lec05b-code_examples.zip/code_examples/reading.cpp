
#include <iostream>
#include <fstream>

#define EXIT_SUCCESS    0

using std::endl;

int main(void) {
   std::istream& inputStream = std::cin;
   double value;
   inputStream >> value;
   std::cout << "Read: " << value << endl;

   return EXIT_SUCCESS;
}
