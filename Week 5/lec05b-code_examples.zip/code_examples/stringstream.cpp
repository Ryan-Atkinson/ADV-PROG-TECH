
#include <iostream>
#include <fstream>
#include <sstream>

#define EXIT_SUCCESS    0

using std::endl;

int main(void) {
   std::string filename("file.txt");
   std::ifstream inFile;
   inFile.open(filename);

   if(inFile.good()) {
      while (!inFile.eof()) {
         // With getline
         std::string line;
         std::getline(inFile, line);
         std::cout << "Read Line: " << line << endl;

         std::stringstream ss(line);
         while (!ss.eof()) {
            std::string word;
            ss >> word;
            std::cout << "\tRead Word: " << word << endl;
         }


      }
   }

   return EXIT_SUCCESS;
}
