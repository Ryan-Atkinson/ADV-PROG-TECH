
#include <iostream>
#include <fstream>

#define EXIT_SUCCESS    0

using std::endl;

int main(void) {
   std::ostream& outputStream = std::cout;
   outputStream << "Some output" << endl;

   return EXIT_SUCCESS;
}
