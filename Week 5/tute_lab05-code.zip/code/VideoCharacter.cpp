#include "VideoCharacter.h"

VideoCharacter::VideoCharacter(std::string& name) :
   name(name)
{}

VideoCharacter::VideoCharacter(VideoCharacter& other) :
    name(other.name)
{}

VideoCharacter::~VideoCharacter() {
}

std::string VideoCharacter::getName() {
   return name;
}
