
#include <iostream>
#include <limits>

#define EXIT_SUCCESS 0

int main (void) {

   int      i;
   std::cout << "i: " << i << std::endl;

   return EXIT_SUCCESS;
}
