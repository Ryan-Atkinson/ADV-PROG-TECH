
#include <cstdio>
#include <iostream>

#define LENGTH          10
#define ROWS            10
#define COLS            5

#define EXIT_SUCCESS    0

void printArray(int array[], int length);

int main (void) {

   int a[LENGTH] = {1};

   int b[LENGTH] = {1, 2, 3, 4};

   int twoD[ROWS][COLS];

   int c[LENGTH] = {-1};

   return EXIT_SUCCESS;
}

void printArray(int array[], int length) {
   for (int i = 0; i < length; ++i) {
      printf("array[%d] = %d\n", i, array[i]);
   }
   std::cout << std::endl;
}
