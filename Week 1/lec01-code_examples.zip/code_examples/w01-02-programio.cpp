
#include <cstdio>
#include <iostream>
#include <string>

int main (void) {

   // Output
   int      i = 10;
   float    f = 2.2356472f;
   double   d = 3.28918734;
   char     c = 'a';


   return 0;
}
