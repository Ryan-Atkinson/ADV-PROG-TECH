
#include <iostream>

#define EXIT_SUCCESS 0

// Declare function first at the top
void foo();

int passing(int x);

int main (void) {

   int      i;
   std::cout << "i: " << i << std::endl;



   return EXIT_SUCCESS;
}

// Define function later
void foo() {
}

int passing(int x) {
   ++x;
   return x;
}
