
#include <cstdio>
#include <iostream>
#include <string>

#define EXIT_SUCCESS 0

using std::string;
using std::cout;

namespace test {
   void foo() {
      cout << "test::foo" << std::endl;
   }

   namespace more {
      void foo() {
         cout << "test::more::foo" << std::endl;
      }
   }
}

void foo() {
   cout << "foo" << std::endl;
}

// Global variable
int globalVariable = 1;

int main (void) {

   // Strings
   string s = "this is a string";
   cout << "string: " << s << std::endl;

   foo();
   test::foo();
   test::more::foo();


   // Global variable
   globalVariable = 10;


   return EXIT_SUCCESS;
}
