
#include <iostream>

#define EXIT_SUCCESS    0

using std::cout;
using std::endl;

void swap(int* a, int* b);

int main (void) {

   int a = 0;

   int* ptr = &a;

   cout << *ptr << endl;

   return EXIT_SUCCESS;
}

void swap(int* a, int* b) {

}
