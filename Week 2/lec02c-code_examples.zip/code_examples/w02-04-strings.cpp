
#include <iostream>

#define LENGTH          10

#define EXIT_SUCCESS    0

using std::cout;
using std::endl;

void printArray(char array[], int length);

int main (void) {

   char string[LENGTH] = "abcd";
   printArray(string, LENGTH);

   return EXIT_SUCCESS;
}

void printArray(char array[], int length) {
   for (int i = 0; i < length; ++i) {
       cout << "string[" << i << "] = " << array[i] << endl;
   }
}
