
#include <iostream>
#include <string>

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;

int pow(int base);
int pow(int base, int power);
// double pow(double base, double power);

template<typename T>
T powGeneric(T base, int power) {
   cout << "Generic pow" << endl;
   T retVal = 1;
   for (int i = 0; i != power; ++i) {
      retVal *= base;
   }
   return retVal;
}

int main(void) {
   int i = 5;
   double d = 2.5;
   int power = 3;

   cout << pow(i) << endl;
   cout << pow(i, power) << endl;

   cout << "Generic calls" << endl;
   cout << powGeneric<int>(i, power) << endl;
   cout << powGeneric<int>(d, power) << endl;
   cout << powGeneric<double>(d, power) << endl;

   return EXIT_SUCCESS;
}

int pow(int base) {
   return pow(base, 2);
}

int pow(int base, int power) {
   cout << "int pow" << endl;
   int retVal = 1;
   for (int i = 0; i != power; ++i) {
      retVal *= base;
   }
   return retVal;
}

// double pow(double base, double power) {
//    cout << "double pow" << endl;
//    double retVal = 1;
//    for (int i = 0; i != power; ++i) {
//       retVal *= base;
//    }
//    return retVal;
// }
