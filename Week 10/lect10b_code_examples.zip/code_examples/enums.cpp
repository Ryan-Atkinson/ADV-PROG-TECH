
#include <iostream>
#include <string>

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;

enum TileCode {
   SQUARE,
   DIAMOND,
   NINJA_STAR
};

int main(void) {
   TileCode tilec = SQUARE;

   if (tilec == DIAMOND) {
      cout << "diamond" << endl;
   } else {
      cout << "Not diamond" << endl;
   }

   return EXIT_SUCCESS;
}
