
#include "LinkedList.h"
#include "LinkedListSize.h"
#include "Node.h"

#include <iostream>
#include <string>

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;


int main(void) {

   LinkedList* list;
   LinkedListSize* llSize = new LinkedListSize();

   list = llSize;
   cout << list->size() << endl;

   list = nullptr;
   list = static_cast<LinkedList*>(llSize);
   cout << list->size() << endl;

   list = nullptr;
   list = dynamic_cast<LinkedList*>(llSize);
   cout << list->size() << endl;


   list = new LinkedList();
//   llSize = static_cast<LinkedListSize*>(list);
    llSize = dynamic_cast<LinkedListSize*>(list);
   if (llSize != nullptr) {
      cout << "***: " << list->size() << endl;
   } else {
      cout << "Nullptr" << endl;
   }


   return EXIT_SUCCESS;
}
