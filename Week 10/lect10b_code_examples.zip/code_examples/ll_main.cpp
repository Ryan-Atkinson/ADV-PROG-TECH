
#include "LinkedList.h"
#include "LinkedListSize.h"

#include <iostream>
#include <string>

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;


int main(void) {
   // LinkedList* list = new LinkedList();
   LinkedList* list = new LinkedListSize();
   list->addBack(99);
   list->addBack(-1);
   list->addBack(7);

   cout << "List Size: " << list->size() << endl;
   for (int i = 0; i < list->size(); ++i) {
      cout << "\t Element[" << i << "]: " << list->get(i) << endl;
   }
   cout << endl;

   cout << "clear" << endl;
   list->clear();
   cout << endl;

   list->addFront(99);
   // list->addFront(-1);
   list->addFront(7);
   cout << "List Size: " << list->size() << endl;
   for (int i = 0; i < list->size(); ++i) {
      cout << "\t Element[" << i << "]: " << list->get(i) << endl;
   }
   cout << endl;

   // Contains
   cout << "contains(-1): " << list->contains(-1) << endl;
   cout << endl;

   cout << "WATCH THE ORDERING OF DELETE!" << endl;
   delete list;

   return EXIT_SUCCESS;
}
