
#include <iostream>
#include <string>

#define EXIT_SUCCESS    0

using std::string;
using std::cout;
using std::endl;

int main(void) {
   auto x = 1;
   cout << x/2 << endl;

   return EXIT_SUCCESS;
}
