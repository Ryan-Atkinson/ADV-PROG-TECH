
#include "LinkedList.h"

#include <stdexcept>
#include <string>

LinkedList::LinkedList() {
   head = nullptr;
   throw std::runtime_error("Not Implemented");
}

LinkedList::~LinkedList() {
   // throw std::runtime_error("Not Implemented");
}

int LinkedList::size() {
   throw std::runtime_error("Not Implemented");
   return 0;
}

void LinkedList::clear() {
   throw std::runtime_error("Not Implemented");
}

int LinkedList::get(int i) {
   throw std::runtime_error("Not Implemented");
   return 0;
}

void LinkedList::addFront(int data) {
   throw std::runtime_error("Not Implemented");
}

void LinkedList::addBack(int data) {
   throw std::runtime_error("Not Implemented");
}

bool LinkedList::contains(int value){
   throw std::runtime_error("Not Implemented");
   return false;
}

void LinkedList::deleteFront() {
   throw std::runtime_error("Not Implemented");
}

void LinkedList::deleteBack() {
   throw std::runtime_error("Not Implemented");
}
