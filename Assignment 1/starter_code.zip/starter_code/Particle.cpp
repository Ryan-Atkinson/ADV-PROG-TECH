
#include "Particle.h"

// x-co-ordinate of the particle
int Particle::getX() {
   return 0;
}

// y-co-ordinate of the particle
int Particle::getY() {
   return 0;
}

// Orientation of the particle
Orientation Particle::getOrientation() {
   return ORIEN_UP;
}
