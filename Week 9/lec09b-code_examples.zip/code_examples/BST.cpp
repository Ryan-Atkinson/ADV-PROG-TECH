
#include "BST.h"

#include <iostream>
#include <string>

using std::string;
using std::cout;
using std::endl;

BST::BST() {
   cout << "BST Constructor: " << endl;
}

BST::~BST() {
   cout << "BST Deconstructor: " << endl;
}

void BST::clear() {
    throw std::runtime_exception("not implemented");
}

bool BST::contains(const int data) const {
   throw std::runtime_exception("not implemented");
}

void BST::add(const int data) {
   throw std::runtime_exception("not implemented");
}
