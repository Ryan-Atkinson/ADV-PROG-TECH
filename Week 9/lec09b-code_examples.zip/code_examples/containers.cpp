#include <iostream>
#include <string>

#include <array>
#include <vector>
#include <deque>
#include <list>

#include <set>
#include <map>
#include <utility>

#define EXIT_SUCCESS    0

using std::cout;
using std::endl;

int main(void) {

   // Array - special initialisation

   // Vector

   // Deque

   // Set

   // Map

   // Tuple

   return EXIT_SUCCESS;
}
