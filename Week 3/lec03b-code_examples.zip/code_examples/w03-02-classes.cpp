
#include <iostream>

#define LENGTH          10
#define EXIT_SUCCESS    0

using std::cout;
using std::endl;


class Example {
public:
   Example(int value);

   void publicMethod();

protected:

   int protectedVariable;
   int protectedMethod(double param);

private:

   double privateArray[LENGTH];
   void privateMethod(int* ptr, double& ref);

};


int main(void) {

   Example example(10);

   return EXIT_SUCCESS;
}

Example::Example(int value) {
   protectedVariable = value;
   privateArray = {1,2,3};
}

void Example::publicMethod() {
   return 0;
}

int Example::protectedMethod(double param) {
   protectedVariable = 10;
   return 0;
}

double Example::privateMethod(int* ptr, double& ref) {
   return 0;
}
