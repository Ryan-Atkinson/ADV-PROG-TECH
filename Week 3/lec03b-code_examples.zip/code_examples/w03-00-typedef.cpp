
#include <iostream>
#include <string>

#define LENGTH          10
#define EXIT_SUCCESS    0

using std::cout;
using std::endl;

// Synonym for existing types
typedef int Integer;
typedef std::string String;

// Can chain typedefs
typedef int* IntPtr;

// Abstraction
typedef double Acceleration;
typedef double Force;
typedef double Mass;

Force netwonsLaw(Mass mass, Acceleration acc);

int main(void) {

   String message = "My falling force = ";
   String units = "m/s^2";
   Force force = netwonsLaw(70, -9.8);
   cout << message << force << units << endl;

   return EXIT_SUCCESS;
}

Force netwonsLaw(Mass mass, Acceleration acc) {
   return mass * acc;
}
