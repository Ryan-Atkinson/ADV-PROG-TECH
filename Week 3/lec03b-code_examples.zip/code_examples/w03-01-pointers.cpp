
#include <iostream>

#define EXIT_SUCCESS    0

using std::cout;
using std::endl;

void swap(int* a, int* b);
void swapRef(int& a, int& b);

int main (void) {

   int a = 0;
   int b = 7;
   int* ptr = NULL;

   cout << ptr << endl;
   if (ptr != NULL) {
      *ptr = 10;
   }

   ptr = &b;
   *ptr = 8;

   cout << b << endl;
   cout << a << endl;
   cout << ptr << endl;
   cout << &a << endl;
   cout << &b << endl;

   swap(&a, &b);
   cout << b << endl;
   cout << a << endl;



   int& ref = a;
   ref = 10;
   ref = b;
   // ref = 7;
   cout << b << endl;
   cout << a << endl;

   // char c = 'a';
   // char* cPtr = &c;

   // int** ptrptr = &ptr;




   return EXIT_SUCCESS;
}








void swap(int* a, int* b) {
   if (a != NULL && b != NULL) {
      int tmp = *a;
      *a = *b;
      *b = tmp;
   }
}

void swapRef(int& a, int& b) {
   int tmp = a;
   a = b;
   b = tmp;
}
