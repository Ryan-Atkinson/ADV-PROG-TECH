
#include <iostream>

#define EXIT_SUCCESS    0
#define LENGTH          10

using std::cout;
using std::endl;

int main (void) {

   int* a = new int(7);
   *a = 10;

   cout << "address: a " << a << ", value = " << *a << endl;

   return EXIT_SUCCESS;
}
