
#include <iostream>

#define EXIT_SUCCESS    0
#define LENGTH          10

using std::cout;
using std::endl;


int main (void) {

   int array[LENGTH] = {1};


   return EXIT_SUCCESS;
}
