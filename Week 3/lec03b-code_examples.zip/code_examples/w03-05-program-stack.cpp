
#include <iostream>

#define EXIT_SUCCESS    0
#define LENGTH          5

using std::cout;
using std::endl;

int foo(int x);

int main (void) {

   int a = 7;
   int b = 8;
   int c = 9;
   int d = 10;

   cout << "address a: " << &a << endl;
   cout << "address b: " << &b << endl;
   cout << "address c: " << &c << endl;
   cout << "address d: " << &d << endl;

   return EXIT_SUCCESS;
}
