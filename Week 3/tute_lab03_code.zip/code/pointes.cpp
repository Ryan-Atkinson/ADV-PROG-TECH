#include <iostream>

using std::cout;
using std::endl;

#define EXIT_SUCCESS    0

int main (void) {

   int a = 7;
   int* ptr = &a;

   cout << a << endl;
   cout << ptr << endl;
   cout << *ptr << endl;

   int b = 10;
   ptr = &b;
   *ptr = 12;
   cout << b << endl;

   int** pptr = &ptr;
   **pptr = 20;
   cout << a << endl;
   cout << b << endl;

   *&**&pptr = &a;
   **pptr = -1;
   cout << a << endl;
   cout << b << endl;

   return EXIT_SUCCESS;
}
